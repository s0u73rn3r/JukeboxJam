# semester-projects-group5
semester-projects-group5 created by GitHub Classroom
### This project requires the user to install Node.js and Electron as of now.
#### Node.js can be installed via the Node.js website
#### After Node is installed, you can use the command npm install electron


# Running JukeboxJam:
To run JukeboxJam:
1) Clone this repository
2) Navigate to the cloned repository
3) Run npm install to install dependencies in package.json
4) Use the command **npm start** to run the program
