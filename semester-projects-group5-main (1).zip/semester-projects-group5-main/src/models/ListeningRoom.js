export default class ListeningRoom {
    constructor(ownerID, name) {
        this._ownerID = ownerID;
        this._name = name;
    }
}